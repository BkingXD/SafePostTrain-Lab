"""SafePostTrain teaching experiments."""
